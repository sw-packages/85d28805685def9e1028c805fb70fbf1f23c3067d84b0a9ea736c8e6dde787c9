<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nn">
    <extra-po-header-language>nn</extra-po-header-language>
    <extra-po-header-language_team>Norwegian Nynorsk &lt;l10n-no@lister.huftis.org&gt;</extra-po-header-language_team>
    <extra-po-header-last_translator>Karl Ove Hufthammer &lt;karl@huftis.org&gt;</extra-po-header-last_translator>
    <extra-po-header-plural_forms>nplurals=2; plural=(n != 1);</extra-po-header-plural_forms>
    <extra-po-header-po_revision_date>2020-05-24 16:08+0200</extra-po-header-po_revision_date>
    <extra-po-header-project_id_version></extra-po-header-project_id_version>
    <extra-po-header-x_generator>Lokalize 20.04.0</extra-po-header-x_generator>
    <extra-po-header_comment># Karl Ove Hufthammer &lt;karl@huftis.org&gt;, 2020.</extra-po-header_comment>
    <extra-po-headers>MIME-Version,Content-Type,Content-Transfer-Encoding,Last-Translator,PO-Revision-Date,Project-Id-Version,Language-Team,Language,Plural-Forms,X-Generator,X-Qt-Contexts</extra-po-headers>
<context>
    <name>QQuickPlatformDialog</name>
    <message>
        <source>Dialog is an abstract base class</source>
        <translation>Dialog er ein abstrakt grunnklasse</translation>
    </message>
    <message>
        <source>Cannot create an instance of StandardButton</source>
        <translation>Kan ikkje oppretta instans av StandardButton</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2ImagineStylePlugin</name>
    <message>
        <source>Imagine is an attached property</source>
        <translation>Imagine er ein tilkopla eigenskap</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2MaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>Material er ein tilkopla eigenskap</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2UniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>Universal er ein tilkopla eigenskap</translation>
    </message>
</context>
</TS>
